package com.gabito.proyects.IntroSpringDataJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
